<template>
    <div id="app">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans&display=swap" rel="stylesheet">
        <router-view/>
    </div>
</template>

<style>
    #app{
        font-family: 'Open Sans', sans-serif;

    }
    body{
        margin: 0
    }
</style>
